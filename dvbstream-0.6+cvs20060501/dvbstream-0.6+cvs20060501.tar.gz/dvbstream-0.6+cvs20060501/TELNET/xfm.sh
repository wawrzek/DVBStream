./svdrpsend.pl -d kenny -p 12345 stop
./svdrpsend.pl -d kenny -p 12345 adda 643:2
