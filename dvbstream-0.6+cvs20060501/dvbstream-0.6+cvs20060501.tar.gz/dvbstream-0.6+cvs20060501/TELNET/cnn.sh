./svdrpsend.pl -d kenny -p 12345 tune 12051 v 27500
./svdrpsend.pl -d kenny -p 12345 addv 2319:1
./svdrpsend.pl -d kenny -p 12345 adda 2321:2

