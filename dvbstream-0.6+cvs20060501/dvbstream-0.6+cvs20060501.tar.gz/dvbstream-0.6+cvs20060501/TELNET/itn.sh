./svdrpsend.pl -d kenny -p 12345 tune 12031 h 27500
./svdrpsend.pl -d kenny -p 12345 addv 2308:1
./svdrpsend.pl -d kenny -p 12345 adda 2310:2

